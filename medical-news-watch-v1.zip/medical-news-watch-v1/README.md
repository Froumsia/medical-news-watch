# Medical News Watch

Application PWA de veille médicale scientifique quotidienne, conçue pour GitHub + Vercel + Supabase.

Fonctions initiales : authentification par lien e-mail, recherche, archive cloud, ingestion quotidienne Europe PMC, filtres accès libre, liens article/PDF lorsqu'ils sont légalement accessibles.

Ne jamais mettre de clé secrète dans GitHub. Les clés sont configurées dans Vercel.
