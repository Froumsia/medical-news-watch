# Déploiement

1. Supabase : SQL Editor -> exécuter supabase/schema.sql.
2. GitHub : importer tout le contenu de ce projet dans medical-news-watch.
3. Vercel : Import Project -> dépôt GitHub.
4. Variables Vercel : NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY, CRON_SECRET.
5. Déployer.

Le cron de vercel.json appelle /api/ingest quotidiennement. Aucun paywall n'est contourné.
